let nome = "Leticia";
let numero = 72;
let usuarioVerificado = false;
let pessoa = null;

/* if (usuarioVerificado) {
  console.log("Usuário verificado");
} else {
  console.log("Usuário NÃO verificado");
} */
